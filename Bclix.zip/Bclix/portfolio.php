<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bclix Technologies</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="images/icons/icon.png" rel="icon">
  <link href="images/icons/icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">


</head>

<style type="text/css">
        .card
        {
          border-style: none;
          height: 500px;
          box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
        }
         .card:hover
        {
        box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;
        }

        h4
        {
          margin-top:20px;
          font-weight: 650;
        }
</style>

<body>

  <!-- ======= Top Bar ======= -->
<?php include('includes/header.php'); ?>
  <!-- ======= Hero Section ======= -->

  <div class="container">

    <!-- ======= Why Us Section ======= -->
  

   
<div class="row mt-5">
</div>



<div class="row mt-3">
  <div><center><h2 data-aos="fade-right" data-aos-delay="200"><u>Portfolio</u></h2></center></div>
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p1.jpg" height="300px" width="100%"></div>
          <div><h4>Vehical Tool Plaza Management System</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Oman <img src="images/flags/oman.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p2.jpg" height="300px" width="100%"></div>
          <div><h4>Dynamic Ecomerce Package For Electronic Business With Admin Panel</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Finland <img src="images/flags/finland.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>


  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p3.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Resturant Automation With Admin Panel</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Pakistan <img src="images/flags/pak.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p4.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Hotel Reservation System</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Canada <img src="images/flags/canada.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>



  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p5.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Cyber Issue Solver</h4></div>
          <div><p> <i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In China <img src="images/flags/china.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p6.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Business Legalization</h4></div>
          <div><p> <i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Dubai <img src="images/flags/dubai.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>


  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p7.jpg" height="300px" width="100%"></div>
          <div><h4>Fully Dynamic Ecomerce Package With Admin Panel</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In UK <img src="images/flags/uk.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p8.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Shopify Synchronizer (Products,Inventory,Product Media,Orders...)</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Italy <img src="images/flags/italy.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>


  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p9.jpg" height="300px" width="100%"></div>
          <div><h4>Attractive Shopify Store </h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Karachi Pakistan <img src="images/flags/pak.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p10.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Inventory Synchronizer From Vendor To Shopify</h4></div>
          <div><p> <i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Italy <img src="images/flags/italy.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>



  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p12.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Food Delievery Package(Chef,Buyer,Admin)</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Australia <img src="images/flags/aus.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p13.jpg" height="300px" width="100%"></div>
          <div><h4>Intelligent School Automation Package(Student,Staff,Admin)</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Pakistan <img src="images/flags/pak.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>

  <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
      <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p14.jpg" height="300px" width="100%"></div>
          <div><h4>Pace Group Of Colleges(Software,Website,Student App,Staff App,LMS)</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In Faislabad Pakistan <img src="images/flags/pak.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="400">
        <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p15.jpg" height="300px" width="100%"></div>
          <div><h4>Smart Shopify And Vendor Api Integration(Product,Product Varient,Product Meida,Inventory)</h4></div>
          <div><p><i class="bx bx-map" style="font-size:18px;color: #FD6802;"></i> Deployed In India <img src="images/flags/india.png" height="20px" width="25px"></p></div>
        </div>
      </div>
     </div>
  </div>

   <div class="row mt-3">
    <div class="col-md-6 col-lg-6  col-sm-6" data-aos="fade-up" data-aos-delay="200">
     <div class="card">
        <div class="card-body">
          <div><img src="images/portfolio/p16.jpg" height="300px" width="100%"></div>
          <div><h4>Dynamic Responsive Website For Aluminium & Glass</h4></div>
          <div><p><i class="bx bx-map" style="font-size:20px;color: #FD6802;"></i> Deployed In Dubai <img src="images/flags/dubai.png" height="20px" width="25px"></p></div>
        </div>
      </div>
    </div>
     <div class="col-md-6 col-lg-6  col-sm-6">
     </div>
  </div>
  
  
</div>
    <!-- ======= Portfolio Section ======= -->
  
    <!-- ======= Contact Section ======= -->
  <section id="contact" class="contact text-center">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-up">Contact</h2>
          <p data-aos="fade-up"></p>
        </div>

        <div class="row justify-content-center">

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" >
            <div class="info-box"  style="padding: 4px;border-radius: 20px;">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
             <p>
              Bahawalnagar,Punjab<br>
              Pakistan <br><br>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="100">
            <div class="info-box"  style="padding: 4px;border-radius: 20px;">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <br>
              <p>Bclixtech@gmail.com</p>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="200">
            <div class="info-box"  style="padding: 4px;border-radius: 20px;">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <br>
              <p> +92 3354517851</p>
            </div>
          </div>
        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="300">
          
          <div class="col-xl-5 col-lg-12 mt-4">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

          <div class="col-xl-4 col-lg-12 mt-4">
           <form action="forms/contact.php" method="post" role="form" class="php-email-form">
             <div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=453&amp;height=512&amp;hl=en&amp;q=Bahawalnagar punjab&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://mcpenation.com/">https://mcpenation.com</a></div><style>.mapouter{position:relative;text-align:right;width:100%;height:320px;}.gmap_canvas {overflow:hidden;background:none!important;width:100%;height:320px;}.gmap_iframe {width:100%!important;height:320px!important;}</style></div>
            </form>
          </div>

        </div>

      </div>
    </section>

  <!-- End Contact Section -->

  </div>
  <!-- ======= Footer ======= -->
 <?php include('includes/footer.php'); ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
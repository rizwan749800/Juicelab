<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bclix Technologies</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
  <link href="images/icons/icon.png" rel="icon">
  <link href="images/icons/icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style type="text/css">
  
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 2rem;
  margin: 4rem 1vw;
  padding: 0;
  list-style-type: none;
}

.card {
  position: relative;
  display: block;
  height: 100%;  
  border-radius: calc(var(--curve) * 1px);
  overflow: hidden;
  text-decoration: none;
}

.card__image {      
  width: 100%;
  height:300px;
}

.card__overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 1;      
  border-radius: calc(var(--curve) * 1px);    
  background-color:#ff5821;      
  transform: translateY(100%);
  transition: .2s ease-in-out;
  color: white;
  width: 100%;
}

.card:hover .card__overlay {
  transform: translateY(0);
}




.card__description {
  padding: 0 2em 2em;
  margin: 0;
  color:white;
  font-family: "MockFlowFont";   
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  overflow: hidden;
}    
</style>

</head>

<body>

  <!-- ======= Top Bar ======= -->
<?php include('includes/header.php'); ?>
  <!-- ======= Hero Section ======= -->

  <div class="container">

    <!-- ======= Why Us Section ======= -->
  

   
<div class="row mt-5">
</div>



<div class="row mt-3">
  <div><center><h2>Portfolio</h2></center></div>
</div>


    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio" class="mt-5">
      <ul class="cards">
  <li>
    <a href="" class="card">
      <img src="images/portfolio/p1.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <p class="card__description">Vehical Tool Plaza Management System<br>Deployed In Oman</p>
      </div>
    </a>      
  </li>
  <li>
    <a href="" class="card">
      <img src="images/portfolio/p2.jpg" class="card__image" alt="" />
      <div class="card__overlay">        
        <p class="card__description">Dynamic Ecomerce Package For Electronic Business With Admin Panel<br>Deployed In Finland </p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="images/portfolio/p3.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <p class="card__description">Smart Resturant Automation With Admin Panel<br>Deployed In Pakistan</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="images/portfolio/p4.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Hotel Reservation System<br>Deployed In Canada</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p5.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Cyber Issue Solver <br>Deployed In China</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p6.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Business Legalization<br>Deployed In Dubai</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p7.jpg" class="card__image" alt="" height="300px" width="100%" />
      <div class="card__overlay">
        <p class="card__description">Fully Dynamic Ecomerce Package With Admin Panel<br>Deployed In UK</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p8.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Shopify Synchronizer (Products,Inventory,Product Media,Orders...)<br>Deployed In Italy</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p9.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Attractive Shopify Store <br>Deployed In Karachi Pakistan</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p10.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Inventory Synchronizer From Vendor To Shopify<br>Deployed In Italy</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p11.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Smart Food Delievery Package(Chef,Buyer,Admin)<br>Deployed In Australia</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p12.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Intelligent School Automation Package(Student,Staff,Admin)<br>Deployed In Pakistan</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p13.jpg" class="card__image" alt="" height="300px" />
      <div class="card__overlay">
        <p class="card__description">Car Wash Reservation System(Website,Admin Panel)<br>Deployed In USA </p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p14.jpg" class="card__image" alt="" height="300px" width="100%" />
      <div class="card__overlay">
        <p class="card__description">Pace Group Of Colleges(Software,Website,Student App,Staff App,LMS)<br>Deployed In Faislabad Pakistan</p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p15.jpg" class="card__image" alt="" height="300px" width="100%" />
      <div class="card__overlay">
        <p class="card__description">Smart Shopify And Vendor Api Integration(Product,Product Varient,Product Meida,Inventory)<br>Deployed In India </p>
      </div>
    </a>
  </li>    

   <li>
    <a href="" class="card">
      <img src="images/portfolio/p16.jpg" class="card__image" alt="" height="300px" width="100%" />
      <div class="card__overlay">
        <p class="card__description">Dynamic Responsive Website For Aluminium & Glass <br>Deployed In Dubai</p>
      </div>
    </a>
  </li>    
</ul>
    </section><!-- End Portfolio Section -->

 

    <!-- ======= Contact Section ======= -->
  <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2 data-aos="fade-up">Contact</h2>
          <p data-aos="fade-up"></p>
        </div>

        <div class="row justify-content-center">

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up">
            <div class="info-box">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
             <p>
              Bahawalnagar,Punjab<br>
              Pakistan <br><br>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="100">
            <div class="info-box">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <br>
              <p>Bclixtech@gmail.com</p>
            </div>
          </div>
          <div class="col-xl-3 col-lg-4 mt-4" data-aos="fade-up" data-aos-delay="200">
            <div class="info-box">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <br>
              <p> +92 3354517851</p>
            </div>
          </div>
        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="300">
          
          <div class="col-xl-5 col-lg-12 mt-4">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

          <div class="col-xl-4 col-lg-12 mt-4">
           <form action="forms/contact.php" method="post" role="form" class="php-email-form">
             <div class="mapouter"><div class="gmap_canvas"><iframe class="gmap_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=453&amp;height=512&amp;hl=en&amp;q=Bahawalnagar punjab&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://mcpenation.com/">https://mcpenation.com</a></div><style>.mapouter{position:relative;text-align:right;width:100%;height:320px;}.gmap_canvas {overflow:hidden;background:none!important;width:100%;height:320px;}.gmap_iframe {width:100%!important;height:320px!important;}</style></div>
            </form>
          </div>

        </div>

      </div>
    </section>

  <!-- End Contact Section -->

  </div>
  <!-- ======= Footer ======= -->
 <?php include('includes/footer.php'); ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
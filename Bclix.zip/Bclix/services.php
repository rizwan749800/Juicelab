<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bclix Technologies</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
  <link href="images/icons/icon.png" rel="icon">
  <link href="images/icons/icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>
<style type="text/css">
  body
  {
   
  }
</style>
<body>

  <!-- ======= Top Bar ======= -->
<?php include('includes/header.php'); ?>
  <!-- ======= Hero Section ======= -->
 

      <section id="services" class="services section-bg">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Services</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6" data-aos="fade-up">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-display"></i></div>
              <h4 class="title"><a href="">Web Development</a></h4>
              <p class="description">Bclix deliveres Software solutions with remarkable functionality and usability from within a browser's window.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-android2"></i></div>
              <h4 class="title"><a href="">Android App Development</a></h4>
              <p class="description">Mobile apps can help you grow brand engagement. Avori can develop an intuitive, fast, creative and interactive app.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><img src="images/icons/soft1.png" height="30px" width="30px"></div>
              <h4 class="title"><a href="">Software Development</a></h4>
              <p class="description">You spotted an opportunity for a new app and want to realize that idea and sell it to the world as a Software-as-a-Service (SaaS) platform.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bi bi-gear-wide"></i></div>
              <h4 class="title"><a href="">Maintenance & Support</a></h4>
              <p class="description">From priority bug-fixing, technical investigations and change requests, we’ll support and maintain your software throughout its life.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><img src="images/icons/shop.png" height="30px" width="30px"></div>
              <h4 class="title"><a href="">Shopify</a></h4>
              <p class="description">Shpify Store can help you grow brand engagement.Bclix can develop an intuitive, fast, creative and interactive Stores.</p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="icon-box">
              <div class="icon"><img src="images/icons/amazon.png" height="30px" width="30px"></div>
              <h4 class="title"><a href="">Amazon</a></h4>
              <p class="description">Ecomerce Pearls can help you grow brand engagement.Pearls Provide an intuitive, fast, creative and Virtual Assistant.</p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

  <!-- ======= Footer ======= -->
 <?php include('includes/footer.php'); ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bclix Technologies</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
  <link href="images/icons/icon.png" rel="icon">
  <link href="images/icons/icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Top Bar ======= -->
<?php include('includes/header.php'); ?>


  <main id="main">
    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container">

       <!--  <div class="section-title">
          <h2 data-aos="fade-up">Pricing</h2>
          <p data-aos="fade-up">Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div> -->

        <div class="row">

          

          <div class="col-lg-4 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="100">
            <div class="box featured">
              <h3>Silver</h3>
              <div class="fw-bold h2" style="color: #ff5821;"><span id="pricetotal" ></span><span>$</span></div><hr>
              <div class="row mt-3" style="text-align: left;">
                <div class="col-md-6">
                   <label>Business Category</label>
                    <select class="form-control">
                      <option >Select</option>
                      <option>E-Commerce</option>
                      <option>Retail</option>
                      <option>Wholesale</option>
                      <option>Bloging</option>
                      <option>Education</option>
                      <option>Food</option>
                      <option>Health</option>
                      <option>Transport</option>
                    </select>
                </div>
                <div class="col-md-6" >
                  <label>Software Type</label>
                  <select class="form-control">
                    <option>Select</option>
                    <option>Software</option>
                    <option>Website</option>
                  </select>
                </div>
              </div><hr>
              <div class="row mt-3" style="text-align:left; ">
                <div class="mb-2">Mandatory Pages</div>
                <div class="col-md-4">
                  <label>Home</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>Contact</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>About Us</label>
                  <input type="checkbox" name="" >
                </div>
              </div><hr>
              <div class="row mt-2" style="text-align: left;">
                <div class="col-md-6">
                  <label>Total Pages</label>
                  <input type="number" name="" class="form-control" id="qty">
                </div>
                <div class="col-md-6">
                  <label>Per Page Cost</label>
                  <input type="text" name="" class="form-control" id="price" placeholder="in dollars $"> 
                </div>
              </div>
    
              <div class="btn-wrap">
                <a href="#" class="btn-buy" onclick="calculateforSilver()">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box">
              <h3>Gold</h3>
              <div class="fw-bold h2" style="color: #ff5821;"><span id="goldpricetotal" ></span><pan>$</span></div><hr>
              <div class="row mt-3" style="text-align: left;">
                <div class="col-md-6">
                   <label>Business Category</label>
                    <select class="form-control">
                      <option >Select</option>
                      <option>E-Commerce</option>
                      <option>Retail</option>
                      <option>Wholesale</option>
                      <option>Bloging</option>
                      <option>Education</option>
                      <option>Food</option>
                      <option>Health</option>
                      <option>Transport</option>
                    </select>
                </div>
                <div class="col-md-6" >
                  <label>Software Type</label>
                  <select class="form-control">
                    <option>Select</option>
                    <option>Software</option>
                    <option>Website</option>
                  </select>
                </div>
              </div><hr>
                <div class="row mt-3" style="text-align:left; ">
                <div class="mb-2">Mandatory Pages</div>
                <div class="col-md-4">
                  <label>Home</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>Contact</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>About Us</label>
                  <input type="checkbox" name="" >
                </div>
              </div><hr>
              <div class="row mt-2" style="text-align: left;">
                <div class="col-md-6">
                  <label>Total Pages</label>
                  <input type="number" name="" class="form-control" id="qty1">
                </div>
                <div class="col-md-6">
                  <label>Per Page Cost</label>
                  <input type="text" name="" class="form-control" id="price1" placeholder="in dollars $"> 
                </div>
              </div>
              <div class="btn-wrap">
                <a href="#" class="btn-buy" onclick="calculateforGold()">Buy Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <span class="advanced">Advanced</span>
              <h3>Diamond</h3>
                   <div class="fw-bold h2" style="color: #ff5821;"><span id="Diapricetotal" ></span><span>$</span></div><hr>
              <div class="row mt-3" style="text-align: left;">
                <div class="col-md-6">
                   <label>Business Category</label>
                    <select class="form-control">
                      <option >Select</option>
                      <option>E-Commerce</option>
                      <option>Retail</option>
                      <option>Wholesale</option>
                      <option>Bloging</option>
                      <option>Education</option>
                      <option>Food</option>
                      <option>Health</option>
                      <option>Transport</option>
                    </select>
                </div>
                <div class="col-md-6" >
                  <label>Software Type</label>
                  <select class="form-control">
                    <option>Select</option>
                    <option>Software</option>
                    <option>Website</option>
                  </select>
                </div>
              </div><hr>
                <div class="row mt-3" style="text-align:left; ">
                <div class="mb-2">Mandatory Pages</div>
                <div class="col-md-4">
                  <label>Home</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>Contact</label>
                  <input type="checkbox" name="" >
                </div>
                <div class="col-md-4">
                   <label>About Us</label>
                  <input type="checkbox" name="" >
                </div>
              </div><hr>
              <div class="row mt-2" style="text-align: left;">
                <div class="col-md-6">
                  <label>Total Pages</label>
                  <input type="number" name="" class="form-control" id="qty2">
                </div>
                <div class="col-md-6">
                  <label>Per Page Cost</label>
                  <input type="text" name="" class="form-control" id="price2" placeholder="in dollars $"> 
                </div>
              </div>
              <div class="btn-wrap">
                <a href="#" class="btn-buy" onclick="calculateforDiamond()">Buy Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php include('includes/footer.php'); ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>

<script type="text/javascript">

      function calculateforSilver() {


        var quantity = document.getElementById('qty').value;
        
        
        var price = document.getElementById('price').value;
       

        var result = quantity * price;
     
        document.getElementById('pricetotal').innerHTML=result;   
    }


     function calculateforGold() {


        var quantity = document.getElementById('qty1').value;
        
        
        var price = document.getElementById('price1').value;
       

        var result = quantity * price;
     
        document.getElementById('goldpricetotal').innerHTML=result;   
    }



     function calculateforDiamond() {


        var quantity = document.getElementById('qty2').value;
        
        
        var price = document.getElementById('price2').value;
       

        var result = quantity * price;
     
        document.getElementById('Diapricetotal').innerHTML=result;   
    }

</script>

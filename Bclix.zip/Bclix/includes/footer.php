 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <img src="images/logo.png" class="img-fluid">
            <p>
              Jahanger Garden <br>
              Bahawalnagar,Punjab<br>
              Pakistan <br><br>
              <strong>Phone:</strong> +92335-4517851<br>
              <strong>Email:</strong> bclixtech@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.php">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="Services.php">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="portfolio.php">Portfolio</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">FAQS</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i>Web Design</li>
              <li><i class="bx bx-chevron-right"></i>Web Development</li>
              <li><i class="bx bx-chevron-right"></i>Shopify</li>
              <li><i class="bx bx-chevron-right"></i>Amazon</li>
              <li><i class="bx bx-chevron-right"></i>Graphic Design</li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Bclix technologies is a software company with highly experienced & visionary staff. We have provided IT solutions to pakistan's major businesses like Transport, Education, Pharmacy and Local Businesses. </p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-lg-flex py-4">

      <div class="me-lg-auto text-center text-lg-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Bclix Tech</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
         
          Designed by <a href="">Bclix Team</a>
        </div>
      </div>
      <div class="social-links text-center text-lg-right pt-3 pt-lg-0">
        
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

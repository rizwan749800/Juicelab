<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bclix Technologies</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <!-- Favicons -->
  <link href="images/icons/icon.png" rel="icon">
  <link href="images/icons/icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Top Bar ======= -->
<?php include('includes/header.php'); ?>
  <!-- ======= Hero Section ======= -->
   <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
      <div class="container">

        <div class="row">
          <div class="col-xl-5 col-lg-6 mt-5 d-flex justify-content-center align-items-stretch position-relative" data-aos="fade-right">
              <img src="images/Gallery/1.jpg" height="700px" width="100%">
          
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
            <h4 data-aos="fade-up">About us</h4>
            <h3 data-aos="fade-up">We Are Bclix Technologies</h3>
            <p data-aos="fade-up">Bclix technologies is a software company with highly experienced & visionary staff. We have provided IT solutions to pakistan's major businesses like Transport, Education, Pharmacy and Local Businesses. We are having deployment in more than 15 cities of pakistan.Now we are launching our mega project Bclix Training Centers in more than 45 cities.
            We are empowering youth with technical skills to cope with unemployment and generate their own income sources.We are also offering jobs for experienced & professionals as we train fresh graduates. Moreover we offer shared business to professionals in order to promote enterpreneurship mindset in Pakistan.</p>

            <div class="icon-box" data-aos="fade-up">
              <div class="icon"><i class="bx bx-fingerprint"></i></div>
              <h4 class="title"><a href="">Collaboration</a></h4>
              <p class="description">
                We value team over the individual, our success is driven by our ability to build relationships and connect across teams and geographies
                  </p>

                </div>

             <div class="icon-box" data-aos="fade-up" data-aos-delay="170">
              <div class="icon"><i class="bx bx-trending-up"></i></div>
              <h4 class="title"><a href="">Flexibility</a></h4>
              <p class="description">We are open to change and we are open to others’ view-points. We are committed to accommodating for the need of clients, employees, and partners.</p>
            </div>
           

            <div class="icon-box" data-aos="fade-up" data-aos-delay="170">
              <div class="icon"><i class="bx bx-atom"></i></div>
              <h4 class="title"><a href="">Integrity</a></h4>
              <p class="description">Integrity is the defining quality of our team and our work.We are accountable and take ownership for the quality of our individual work but also take pride in what we deliver as a team</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php include('includes/footer.php'); ?>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Latest compiled and minified CSS -->

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Harmonia+Sans:ital,wght@0,400&display=swap" rel="stylesheet">
	
	<title>JuiceLab</title>
</head>

<style>
	body
	{
		font-family: 'Harmonia Sans', sans-serif;
	}
	.next a
	{
     text-decoration: none;
	}
	.next a:hover
	{
     text-decoration:underline;
	}
@media only screen and (max-width:576px)
 {
.top
{
 margin-top: -70px;
 
}
}
  @media only screen and (max-width:768px)
 {
.top
{
 margin-top: -70px;
 
}
}
@media only screen and (max-width:576px)
 {
.top
{
line-height:34px;
 
}
}
  @media only screen and (max-width:768px)
 {
.media
{
 line-height:34px;
 
}
}
.but:hover
{
    color:white;
    background:#110a4f;
    border:none;
}



@media only screen and (max-width:576px)
 {
.media strong
{
 font-size:35px;
 
}
}
  @media only screen and (max-width:768px)
 {
.media strong
{
font-size:35px;
}
}
</style>
<body>

<?php include('include/header.php') ?>


<div class="container "  style="margin-top:-13px;">
   
	<div class="row">
	   <div class="col-md-6 col-lg-6 col-12 col-sm-12 top">
	   <center><img src="images/juicer.webp" style="border-radius: 10px;" width="100%" height="25%"></center>	
	   </div>



	   <div class="col-md-6 col-lg-6 col-sm-12 col-12">
        
              	<!-- Price -->
             <div class="container">
	   	<div class="mt-2"><small style="font-size:12px;font-weight:300;color:gray;">العصارة الذكية</small></div>
	   	 <div ><p class="media" style="color:#110a4f;font-size:50px;"><strong>عصارة الفواكه الذكية  <br>(جودة ممتازة) </strong></p></div>
	   	 <div class="row">
	   	 	<div class="col-auto"><del style="color:#110a4f;"><small>Dhs.260.00 AED</small></del></div>
	   	 	<div class="col-auto"><p style="color:#110a4f;"><small>Dhs.120.00 AED</small></p></div>
	   	 	<div class="col-auto"><button class="btn btn-sm" style="background:#110a4f;color: white;border-radius: 15px;width: 60px;"><small>Sale</small></button></div>
	   	 </div>
	  
	 
     <div class="row"> 
      	<div class="col-md-4  col-sm-6 col-6" >
      		<div class="mt-4 font-weight-bolder"><small >الكمية</small></div>
          <div>
          	 <div class="counter mt-2" style="border: 1px solid #110a4f;width: 150px;border-radius: 10px;float:left ;padding:3px 0px;">
			      <span class="down" style="color:#110a4f;" onClick='decreaseCount(event, this)'>-</span>
			      <input type="text" value="1" style="margin-left:10px;color:#110a4f;">
			      <span class="up text-dark" style="margin-left:21px;color:#110a4f;"  onClick='increaseCount(event, this)'>+</span>
			    </div>
          </div>
				  
      	</div>
     	<div class="col-md-7 col-6 col-sm-6 mt-5">
      		<center>
      			<button class="btn btn-lg mt-2 but" style="border:1px solid black">
      			<i class="fa fa-apple"  aria-hidden="true"></i>
      			Pay
      		</button>
      		</center>
      		
      	</div>
      </div>
	   
    
     <div class="container-sm">
		   <div class="row mt-5 pt-2 pb-2" style="background: #e8f4df;">
			   	<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/un.png" width="50px"></center>
			   		<center><p><strong>توصيل مجاني إلى جميع الإمارات   </strong> </p></center>

			   	</div>
			   		<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/24.png" class="mt-2" width="50px"></center>
			   		<center><p><strong>خدمة ما بعد البيع  </strong></p></center>
			   	</div>
			   		<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/like.png" width="40px" class="mt-2"></center>
			   		<center><p class=""><strong>مان استرجاع المنتج  </strong> </p></center>
			   	</div>
		   </div>
		 </div>


		 <div class="container-sm mt-2">
		 	<div class="row">
		 		<div class="col-md-12 col-sm-12 col-12">
		 			<div class="next"><a href="productlist.php" style="color:#4C4E52;">اخبرني المزيد   </a>  <i class="fa text-muted fa-arrow-right" style="font-size:10px;"></i></div>
		 		</div>
		 	</div>
		 </div>
   </div>
 </div>
 </div>	
</div>

<!-- Main content -->




<?php include('include/footer.php') ?>




</body>
</html>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>


<script type="text/javascript">
      function increaseCount(a, b) {
        var input = b.previousElementSibling;
        var value = parseInt(input.value, 10); 
        value = isNaN(value)? 0 : value;
        value ++;
        input.value = value;
      }
      function decreaseCount(a, b) {
        var input = b.nextElementSibling;
        var value = parseInt(input.value, 10); 
        if (value > 1) {
          value = isNaN(value)? 0 : value;
          value --;
          input.value = value;
        }
      }
    </script>
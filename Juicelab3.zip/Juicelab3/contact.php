<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>Contact us</title>
</head>

<style>
    body
    {
       color: #110a4f;
    }
     @media only screen and (max-width:576px)
 {
.top
{
 margin-top: -80px;
 
}
}
  @media only screen and (max-width:768px)
 {
.top
{
 margin-top: -100px;
 
}
}
</style>
<body>

<?php include('include/header.php') ?>


<div class="container top">
   
    <div class="row mt-5">
        <div class="col-md-2 col-1"></div>
        <div class="col-md-8 col-sm-10 col-10">
            <div><h1 style="color: #110a4f;"><strong>تواصل معنا</strong></h1></div>
            <form>
                <div class="row">
                    <div class="col-md-6 col-12 col-sm-8 mt-4"><input type="text" class="form-control" placeholder="Name"></div>
                    <div class="col-md-6 col-12 col-sm-8 mt-4"><input type="text" class="form-control" placeholder="Email"></div>
                </div>
                 <div class="row mt-2">
                    <div class="col-md-12 col-12 col-sm-12"><input type="text" class="form-control" placeholder="Phone Number"></div>
                </div>
                 <div class="row mt-2">
                    <div class="col-md-12 col-12 col-sm-12"><textarea cols="100%" rows="7" class="form-control">Comment</textarea></div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-12 col-12 col-sm-12">
                        <button class="btn btn-md" style="background:#110a4f;color: white;"> Send</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-2 col-2"></div>
    </div>
   
  
</div>


<?php include('include/footer.php') ?>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


<?php
session_start();
include('db/db.php');
include('config.php');
\Stripe\Stripe::setVerifySslCerts(false);    // Disabeling SSL certificate
$orderId = "Order# : ".$_SESSION['order_id']; 
$totalAmount = $_SESSION['total_amount']*100;
$userId      = $_SESSION['user_id'] ;
$userName    = $_SESSION['user_name'] ;
$userContact = $_SESSION['user_contact'];
$userEmail   = $_SESSION['user_email'];
$userAddress = $_SESSION['user_address'];
$orderAmount = $_SESSION['total_amount'];
$orderItemList = $_SESSION['orderItemList'];
$chefId = 0;
$chefName='';
$chefContact='';
$chefAddress='';
$chefEmail='';
if(count($orderItemList)>0)
{
    $chefId = $orderItemList[0]->chef_id;
    $chefName = $orderItemList[0]->chef_name;
    $chefContact = $orderItemList[0]->chef_cell;
    $chefAddress = $orderItemList[0]->chef_address;

}

$token = $_POST['stripeToken'];              // Stripe token against transaction verifictaion//
$res   = \Stripe\Charge::create              // Charge function of stripe which will generate transaction to stripe//
(
    array(
        "amount"=>$totalAmount,
        "currency"=>"PKR",
        "description"=>$orderId,
        "source"=>$token

    )
);

if(isset($res->id))
{
    $receiptURL   =  $res->receipt_url;
    $transactionId = $res->id; 
    $saveQry = "INSERT INTO `customer_order`(`group_id`, `mh`, `user_id`, `user_name`, `cell_no`, `address`, `amount`,
     `method`, `delivery_charges`, `payment_status`,`transection_id`, `delivery_status`, `order_status`, `chef_id`, `chef_name`, `chef_contact`,
      `chef_address`, `chef_email`, `payment_gateway`, `account_id`, `account_title`, `feedback`, `receipt_url`, `created_on`,
       `updated_on`, `is_updated`, `is_deleted`) VALUES 
       (1,1,'$userId','$userName','$userContact','$userAddress','$orderAmount','PICK UP','150','Paid','$transactionId',
       'PENDING','OPEN','$chefId','$chefName','$chefContact','$chefAddress','$chefEmail','CREDIT CARD','1','Stripe','',
       '$receiptURL',unix_timestamp()*1000,0,0,0)";
       $res = mysqli_query($con,$saveQry);
       $orderId = mysqli_insert_id($con);

       if(count($orderItemList)>0)
       {
           $saveItem = "INSERT INTO `order_item`( `group_id`, `mh`, `user_id`, `user_name`, `order_id`, `cat_id`,
            `cat_name`, `name`, `chef_id`, `chef_name`, `chef_cell`, `chef_address`, `price`, `image`, `quantity`, `unit`,
             `delivery_time`, `rating`, `created_on`, `updated_on`, `is_updated`, `is_deleted`) VALUES ";
           foreach ($orderItemList as $key) 
           {
               $catId = $key->cat_id;
               $catName = $key->cat_name;
               $name = $key->name;
               $chefId = $key->chef_id;
               $chefName = $key->chef_name;
               $chefCell = $key->chef_cell;
               $chefAddress = $key->chef_address;
               $price = $key->price;
               $image = $key->image;
               $quantity = $key->qty;
               $unit = $key->unit;
               $deliveryTime = $key->delivery_time;
               $rating = $key->rating;

               $saveItem = $saveItem."(1,1,'$userId','$userName','$orderId','$catId','$catName','$name','$chefId','$chefName',
               '$chefCell','$chefAddress','$price','$image','$quantity','$unit','$deliveryTime','$rating',unix_timestamp(),0,0,0),";
           }

          $saveItem = substr($saveItem,0,strlen($saveItem)-1);
          $res = mysqli_query($con,$saveQry);
          if($res)
          {
              echo '<script>alert("Your order has been successfully!");
              window.location="dishes.php"</script>';

          }


       }




}




?>
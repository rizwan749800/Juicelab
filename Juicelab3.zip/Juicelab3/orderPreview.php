<?php
session_start();
include('db/db.php');
include('config.php');

$categoryList = array( );
$maxOrderId = 0;

$qry = "SELECT MAX(id) AS MAX_ID FROM customer_order WHERE  is_deleted=0";
$res = mysqli_query($con,$qry);
if($res)
{
  if(mysqli_num_rows($res)>0)
  {
    $row = mysqli_fetch_array($res);
    $maxOrderId = $row['MAX_ID'];
    $maxOrderId++;
  }
  else
  {
    $maxOrderId=1;
  }
}
else
{
  $maxOrderId=1;
}

$_SESSION['order_id'] = $maxOrderId;

?>

<!DOCTYPE html>

<html class="no-js">
<!--<![endif]-->

<head>
	<title>Checkout</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/main.css" class="color-switcher-link">
	<link rel="stylesheet" href="css/shop.css" class="color-switcher-link">
	<script src="js/vendor/modernizr-2.6.2.min.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="color-main">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image"></div>
	</div>

	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform search-form" action="/">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class="btn">Search</button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls p-normal">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--
		<ul class="list-unstyled">
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div>
	<!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->
<?php include('includes/header.php');?>
			



			<section class="ls s-py-75 s-py-lg-100 shop-cart">
				<div class="container mt-20">
					<div class="row">
						<h4>Review Your Order To Checkout</h4>

						<main class="col-lg-12">

							<form class="woocommerce-cart-form" action="/" method="post">

								<table class="shop_table shop_table_responsive cart">
									<thead>
										<tr>
											
											<th class="product-thumbnail">&nbsp;</th>
											<th class="product-name">Product</th>
											<th class="product-price">Price</th>
											<th class="product-quantity">Quantity</th>
											<th class="product-subtotal">Total</th>
											<th class="product-remove">&nbsp;</th>
										</tr>
									</thead>
									<tbody>

									<?php
             $totalAmount=0;
        foreach ($_SESSION['orderItemList'] as $dish) 
        {
          $totalAmount =$totalAmount+$dish->subTotal;
        ?>

                  <tr class="cart_item">

                  <td class="product-thumbnail">
                      <img src="images/<?php echo $dish->image;?>" height="60" class="rounded">
                    </td >
                   

                    <td class="product-name" data-title="Product">
                      <label style="font-size:25;font-weight: normal;">  <?php echo $dish->name;?> </label>
                      <label class="font-weight-normal badge badge-warning"> <?php echo $dish->cat_name;?> </label>
                    </td >
					<td class="product-price" data-title="Price">
                      <label style="font-size:25;font-weight: normal;">PKR <?php echo $dish->subTotal;?> </label> 
                    </td>
                    <td class="product-quantity" data-title="Quantity">
                    <label class="font-weight-normal "> <?php echo $dish->qty;?> </label>
                    </td>

					<td class="product-price" data-title="Price">
                    <label class="font-weight-normal "> PKR <?php echo $dish->qty*$dish->subTotal;?> </label>
                    </td>

                  
                    <td  class="product-remove">
                    <button type="button" class="btn btn-light text-danger">Remove</button>
                    </td>
                  </tr> 



               
                <?php
              }
              $_SESSION['total_amount'] = $totalAmount; 
              ?>




										<tr>
											<td colspan="6" class="actions">

												<div class="coupon">
													<label for="coupon_code">Coupon:</label>
													<input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Coupon code">
													<input type="submit" class="button apply" name="apply_coupon" value="Apply coupon">
												</div>

												<form action="submit.php" method="POST">
    <script
       src = "https://checkout.stripe.com/checkout.js" class="stripe-button"
       data-key         = "<?php echo $publishKey ?>"
       data-amount      = "<?php echo $totalAmount*100; ?>"
       data-name        = "Prosi Eats"
       data-description = "Order# <?php echo $_SESSION['order_id']; ?>"
       data-image       = "images/pe.PNG"
       data-currency    = "PKR"  
    >
        
    </script>
</form>

											</td>
										</tr>

									</tbody>
								</table>
							</form>



						</main>

						
					</div>

				</div>
			</section>

			<?php include('includes/footer.php'); ?>

		</div>
		<!-- eof #box_wrapper -->
	</div>
	<!-- eof #canvas -->


	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>


</body>

</html>
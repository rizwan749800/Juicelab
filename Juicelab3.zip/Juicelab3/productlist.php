<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Harmonia+Sans:ital,wght@0,400&display=swap" rel="stylesheet">
	
	<title>Product List</title>
</head>
<style type="text/css">

@media only screen and (max-width:576px)
 {
 	.down-text
 	{
 		line-height: 45px;
 	}
.down-text strong
{
 font-size:40px;
 line-height: 10px;
 
}
}
  @media only screen and (max-width:768px)
 {
.down-text strong
{
font-size:40px;
}
}

 
</style>
<body>

<?php include('include/header.php') ?>

<!-- Main content -->
<div class="container " style="margin-top:-15px;">
	<div class="row">
	   <div class="col-md-6 col-lg-6 top">
			   	<div class="row">
	   		 <div class="col-md-12 col-12 col-sm-12">
	   		 	  <div class="carousel-container">
        <div class="carousel-slide">
          <img src="images/1.webp" alt="Image 1">
          <img src="images/2.jpg" alt="Image 2">
          <img src="images/car9.webp" alt="Image 3">
          <img src="images/car10.webp" alt="Image 4">
          <img src="images/car11.webp" alt="Image 4">
          <img src="images/car12.webp" alt="Image 4">
        </div>
        <div class="carousel-thumbnails" style="overflow-x: scroll;">
          <div class="carousel-thumbnails-container">
            <img src="images/car13.png" alt="Thumbnail 1" class="active">
            <img src="images/car14.jpg" alt="Thumbnail 2">
            <img src="images/car15.jpg" alt="Thumbnail 3">
            <img src="images/car16.jpg" alt="Thumbnail 4">
            <img src="images/car17.png" alt="Thumbnail 2">
            <img src="images/car18.png" alt="Thumbnail 3">
           
            <!-- Add more thumbnails here -->
          </div>
        </div>
     </div>
	   		 </div>
	   	</div>
	   </div>
	 
	   <div class="col-md-6 col-lg-6 col-12 col-sm-12 mt-5">

	   	<!-- Price -->
	   	 <div><p class="down-text mt-4" style="font-size: 50px;color: #110a4f;font-family: 'Harmonia Sans', sans-serif;word-spacing:1px;"><strong>عصارة الفواكه الذكية  <br>(جودة ممتازة) </strong></p></div>
	   	 <div class="row">
	   	 	<div class="col-auto"><del><small>Dhs. 260.00 AED</small></del></div>
	   	 	<div class="col-auto"><p>Dhs. 120.00 AED</p></div>
	   	 	<div class="col-auto"><button class="btn btn-sm" style="background:#110a4f;color: white;border-radius: 20px;width: 60px;">Sale</button></div>
	   	 </div>
	  
      <div class="row">
      		<div class="col-md-4  col-sm-6 col-6" >
      		<div class="mt-4 font-weight-bolder"><small >الكمية</small></div>
          <div>
          	 <div class="counter mt-2" style="border: 1px solid #110a4f;width: 150px;border-radius: 10px;float:left ;padding:3px 0px;">
			      <span class="down" style="color:#110a4f;" onClick='decreaseCount(event, this)'>-</span>
			      <input type="text" value="1" style="margin-left:10px;color:#110a4f;">
			      <span class="up text-dark" style="margin-left:21px;color:#110a4f;"  onClick='increaseCount(event, this)'>+</span>
			    </div>
          </div>
				  
      	</div>
      	<div class="col-auto mt-5">
      		<button class="btn btn-lg mt-2 but" style="border:1px solid black">
      			<i class="fa fa-apple"  aria-hidden="true"></i>
      			Pay
      		</button>
      		
      	</div>

      </div>
	   
	   
    



 
	   <!--<div class="row mt-2 ">-->
	   <!--	 <div class="col-md-12 col-sm-12 col-12">-->
	   <!--	 	<center>-->
	   <!--	 			<button class="btn" style="background:#110a4f; width:;color: white;width:100%;padding:10px 0px;">لاكثر من قطعة اختر العدد واضغط هنا </button>-->
	   <!--	 	</center>-->
	   <!--	 </div>-->
	   <!--</div>-->

	     <div class="container-sm">
		   <div class="row mt-5 pt-2 pb-2" style="background: #e8f4df;">
			   	<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/un.png" width="50px"></center>
			   		<center><p><strong>توصيل مجاني إلى جميع الإمارات   </strong> </p></center>

			   	</div>
			   		<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/24.png" class="mt-2" width="50px"></center>
			   		<center><p><strong>خدمة ما بعد البيع  </strong></p></center>
			   	</div>
			   		<div class="col-md-4 col-4 col-sm-4 col-4">
			   		<center><img src="images/like.png" width="40px" class="mt-2"></center>
			   		<center><p class=""><strong>ضمان استرجاع المنتج </strong> </p></center>
			   	</div>
		   </div>
		</div>
   </div>
</div>
</div>

<!-- New Section -->
<div class="container mt-5">
			<div class="row">
				<div class="col-md-4 col-12 mt-1">
				    <div class="row">
				    
				    		<div class="col-12">
				    		    
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong> احصل على كوب عصيرك اليومي في ثواني، عصارة الفواكه الكهربائية تستخلص العصير بسهولة وسرعة لكي تستمتع بالإنتعاش إلى آخر قطرة</strong>	</h5></div>
		                <div><img src="images/2.jpg" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    	
				    </div>

					
				
			</div>
			<div class="col-md-4 col-12 mt-1">
				 <div class="row">
				    	
				    		<div class="col-12">
				    		    <br><br>
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>يمكنك حملها إلى أي مكان. تعمل بالبطارية والشحن عبر منفذ يو اس بي  </strong></h5></div>
				    			<div><img src="images/jun.webp" height="330px" style="border-radius: 14px;width: 100%;"></div>
				    		</div>
				    		
				  </div>
			</div>

			<div class="col-md-4 col-12 mt-1">

				 <div class="row">
				    	
				    		<div class="col-12">
				    		    <br><br>
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>ييمكنك استعمالها في المكتب أو على البحر أو في الحديقة </strong></h5></div>
				    			<div><img src="images/card.webp" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    		
				  </div>
			</div>
		</div>	


		<div class="row">
       <div class="col-md-4 col-12 mt-1">
			 <div class="row">
				    	
				    		<div class="col-12">
				    		    <br><br>
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>انسيابية شكل الجهاز وسهولة تشغيله يجعل منه هدية رائعة للرجال والنساء
			              بالإنتعاش إلى آخر قطرة
			        </strong></h5></div>
				    			<div><img src="images/card2.webp" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    		
				  </div>
				</div>

				<div class="col-md-4 col-12 mt-1">
					<div class="row">
				    	
				    		<div class="col-12">
				    		    <br>
				    		    <br>
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>ي يعصر بشكل فعال إلى القشرة و يمنحك ضعف كمية العصير  الطبيعية و الصحية في ثواني
			                </strong></h5></div>
				    			<div><img src="images/card3.webp" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    		
				  </div>
				</div>

				<div class="col-md-4 col-12 mt-1">
					<div class="row">
				    
				    		<div class="col-12">
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>يابتكر مشروبك, ليس عليك سوى اضافة اختيارك من الفاكهة وضغط الزر لتحصل على كوبك المنعش من العصير. يمكن استخدامها للبرتقال والتفاح والعنب والرمان والكمثرى والفواكه الأخرى
		               	</strong></h5></div>
				    			<div><img src="images/4.webp" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    	
				  </div>
				</div>
	</div>

	<div class="row">
		<div class="col-md-4 col-12">
			<div class="row">
				    	
				    		<div class="col-12">
				    			<div><h5 style="color:#110a4f;text-align: right;"><strong>صغيرة الحجم وسهلة التنظيف وذات جودة  عالية مع ضمان استرجاع وخدمة مابعد البيع	</strong></h5></div>
				    			<div><img src="images/3.webp" height="330px" width="100%" style="border-radius: 14px;"></div>
				    		</div>
				    	
				  </div>
				</div>

				<div class="col-md-4 col-12 mt-3">
			    <div class="row">
				    
				    		<div class="col-12 mt-1">
				    			<div><center><img src="images/logo.png" height="115px" width="100%" style="border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 6px;"></center></div>
				    		</div>
				    	
				  </div>
				</div>
				<div class="col-md-4 col-12"></div>
	</div>
	
</div>
<!-- end -->

<div class="row mt-3">

	<div class="col-md-4 col-12 col-sm-12 mt-2" >
		<a href="" class="text-dark text-decoration-none"><img src="images/arr.png" height="23px" style="margin-left:10px;"> Share</a>
		<hr style="color:slategray;">
	</div>
	<div class="col-md-4 col-12 col-sm-12 tog" >
		<div class="row">
			<div class="col-md-12" onclick="toggleContent(1,this)"><span><img src="images/tr.png" height="20px" style="margin-left:10px;">   <strong style="color:#110a4f;margin-left:30px">التوصيل  </strong><i class=" fa fa-chevron-down" style="float:right;color:#110a4f;padding-right:17px;"></i> </span></div>
		</div>

		<div class="row mt-2">
			<div class="col-md-12 content" id="content1"><p style="color:#110a4f;margin-left:10px;">توصيل مجاني وسريع إلى جميع أنحاء الإمارات</p></div>
		</div>
	<hr style="color:slategray;">
	</div>

	<div class="col-md-4 col-12 col-sm-12 tog" onclick="toggleContent(2)">
		<div class="row">
			<div class="col-md-12" onclick="toggleContent(2,this)"><span><img src="images/sh.png" height="20px" style="margin-left:10px;"><strong style="color:#110a4f;margin-left:30px"> سياسة الإسترجاع  </strong><i class=" fa fa-solid fa-chevron-down" style="float: right;color:#110a4f;padding-right:17px;"></i></span></div>
		</div>
		<div class="row">
			<div class="col-md-12 content mt-2" id="content2"> 
				<p style="color:#110a4f;margin-left:10px;">تواصل معنا في أي وقت لإرجاع المنتج أو المبلغ.</p>
			</div>
		</div>
		<hr style="color:slategray;">
	</div>

</div>




<!-- You may -->
<div class="container mt-5">
	<div class="row">
     	<div class="col-md-4 col-sm-7 col-7">
		<div><h4 style="color:#110a4f;"><strong>You may also like</strong></h4></div>
		<div class="card w-100" style="border-style: none;">
			<div class="card-body">
				<img src="images/juicer.webp" style="border-top-right-radius: 10px;border-top-left-radius: 10px;" width="100%" height="24%">
				<div><p><strong>  صغيرة الحجم وسهلة  التنظيف وذات جودة  عالية مع <br> ضمان استرجاع وخدمة مابعد البيع  </p></div>
				<div><del><small>Dhs.300.00 AED</small></del><p>Dhs.200.00 AED</p> </div>
			</div>
		</div>
	</div>

   </div>
</div>


<?php include('include/footer.php') ?>





</body>
</html>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script type="text/javascript">
      function increaseCount(a, b) {
        var input = b.previousElementSibling;
        var value = parseInt(input.value, 10); 
        value = isNaN(value)? 0 : value;
        value ++;
        input.value = value;
      }
      function decreaseCount(a, b) {
        var input = b.nextElementSibling;
        var value = parseInt(input.value, 10); 
        if (value > 1) {
          value = isNaN(value)? 0 : value;
          value --;
          input.value = value;
        }
      }
      function toggleContent(id, element) {
    var content = document.querySelector('#content' + id);
    var down = element.querySelector('.fa-chevron-down');
    content.style.display = content.style.display === 'none' ? 'block' : 'none';
    down.classList.toggle('rotate');
  }
  
    const slide = document.querySelector(".carousel-slide");
const thumbnailsContainer = document.querySelector(".carousel-thumbnails-container");
const thumbnails = document.querySelectorAll(".carousel-thumbnails img");
const thumbnailWidth = thumbnails[0].offsetWidth + 10;
const thumbnailContainerWidth = thumbnailWidth * thumbnails.length;
thumbnailsContainer.style.width = `${thumbnailContainerWidth}px`;

thumbnails.forEach((thumbnail, index) => {
  thumbnail.addEventListener("click", () => {
    slide.scroll({
      left: slide.offsetWidth * index,
      behavior: "smooth",
    });
    thumbnails.forEach((thumbnail) => {
      thumbnail.classList.remove("active");
    });
    thumbnail.classList.add("active");
  });
});

let thumbnailPosition = 0;

function moveThumbnails(direction) {
  if (direction === "left") {
    thumbnailPosition -= thumbnailWidth;
    if (thumbnailPosition < 0) {
      thumbnailPosition = 0;
    }
  } else if (direction === "right") {
    thumbnailPosition += thumbnailWidth;
    const maxPosition = thumbnailContainerWidth - thumbnailsContainer.offsetWidth;
    if (thumbnailPosition > maxPosition) {
      thumbnailPosition = maxPosition;
    }
  }
  thumbnailsContainer.style.transform = `translateX(-${thumbnailPosition}px)`;
}

document.querySelector(".carousel-thumbnails-arrow.left").addEventListener("click", () => {
  moveThumbnails("left");
});

document.querySelector(".carousel-thumbnails-arrow.right").addEventListener("click", () => {
  moveThumbnails("right");
});

window.addEventListener("resize", () => {
  thumbnailWidth = thumbnails[0].offsetWidth + 10;
  thumbnailContainerWidth = thumbnailWidth * thumbnails.length;
  thumbnailsContainer.style.width = `${thumbnailContainerWidth}px`;
});


    </script>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<title>Cart</title>
</head>
<body>

<?php include('include/header.php') ?>

<!-- Content -->
<div class="container">
	<div class="row">
			<div class="col-md-4 col-sm-6 col-6">
		      <h1 style="color: #110a4f;"><strong>Your cart</strong></h1>
	    </div>
	    <div class="col-md-4 col-sm-6 col-6">
	    </div>
				<div class="col-md-4 col-sm-6 col-6 mt-1"><p><a href="product.php">Continue shopping</a></p></div>
	</div>
</div>


<div class="container mt-5">
	<div class="row">
		
		<div class="col-md-3 col-sm-4 col-4 order-1 order-sm-1"><p>Product</p>
		<hr><div><img src="images/juicer.webp" height="100px" width="90%" style="border-radius: 20px;"></div></div>
		<div class="col-md-3 col-sm-4 col-4 mt-4 order-2 order-sm-2"><hr><h4 style="color:#110a4f;">عصارة الفواكه الذكية (جودة ممتازة) </h4><p>Dhs.120.00</p></div>
		<div class="col-md-3 col-sm-4 col-4 order-4 order-sm-3"><p>Quantity</p><hr> <div class="counter mt-2" style="border: 1px solid black;width: 110px;border-radius: 10px;">
			      <span class="down" onClick='decreaseCount(event, this)'>-</span>
			      <input type="text" value="1">
			      <span class="up"  onClick='increaseCount(event, this)'>+</span>
			    </div></div>
		<div class="col-md-3 col-sm-4 col-4 order-3 order-sm-4"><h5>Total </h5><hr><p class="mt-5">Dhs.120.00</p></div>
	</div>
</div>






<!-- Form -->
<!--<div class="container mt-4">-->
<!--	<div class="row mt-2 w-100">-->
<!--	<div class="col-md-3"></div>-->
<!--<div class="col-md-6 col-sm-12 col-12">-->
<!--	<div class="card pt-5 pb-5" style="box-shadow: rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px;">-->
<!--	   	<div class="card-body">-->

<!--	   	<div class="input-group mb-3" style="width:80%;height: 40px;">-->
<!--		  <span class="input-group-text" id="basic-addon1"><i class="fa fa-user"></i></span>-->
<!--		  <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1">-->
<!--		</div>-->

<!--		<div class="input-group mb-3" style="width:80%;height: 40px;">-->
<!--		  <span class="input-group-text" id="basic-addon1"><i class="fa fa-lock"></i></span>-->
<!--		  <input type="text" class="form-control" placeholder="password" aria-label="Username" aria-describedby="basic-addon1">-->
<!--		</div>-->

<!--		<div class="btn btn-dark w-100 mt-4"><i class="fa fa-shopping-bag text-white ml-5" aria-hidden="true"></i> الشراء بالدفع عند الاستلام   </div>-->

<!--	   	</div>-->
<!--	   </div>-->
<!--</div>-->
<!--<div class="col-md-3"></div>-->
<!--</div>-->
<!--</div>-->


<!-- End of form -->



<?php include('include/footer.php') ?>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script type="text/javascript">
      function increaseCount(a, b) {
        var input = b.previousElementSibling;
        var value = parseInt(input.value, 10); 
        value = isNaN(value)? 0 : value;
        value ++;
        input.value = value;
      }
      function decreaseCount(a, b) {
        var input = b.nextElementSibling;
        var value = parseInt(input.value, 10); 
        if (value > 1) {
          value = isNaN(value)? 0 : value;
          value --;
          input.value = value;
        }
      }
    </script>
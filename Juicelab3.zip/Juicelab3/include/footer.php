
<div class="text-white pb-3 pt-3 w-100 mt-3" style="background:#110a4f;">
	<h3 class="text-center mt-2"><strong>احصل على عصير طازج خلال ثواني  </strong></h3>
		<p class="text-center mt-3">مع عصارة الفواكه الكهربائية القابلة للشحن  </p>
</div>



<div class="container-fluid">
    <div class="row bg-dark pt-3 pb-2">
      <div class="col-auto">
          <p class="text-white mt-2" style="">الكمية</p>
      </div>
       <div class="col-auto">
           	 <div class="counter" style="border: 1px solid white;width: 110px;border-radius:8px;padding:0px 0px;margin-left:1px;">
			      <span class="down text-white" style="font-size:18px;" onClick='decreaseCount(event, this)'>-</span>
			      <input type="text" value="1" class="bg-dark text-white" style="height:35px;">
			      <span class="up text-white" style="font-size:18px;"  onClick='increaseCount(event, this)'>+</span>
			 </div>
       </div>
        <div class="col-auto"></div>
</div>
</div>

				


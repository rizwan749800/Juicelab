<div>
<div class="row1 text-center text-white" style="background:#110a4f;padding: 4px 0px;">
		<h6 class="mt-1" style="font-weight:500;font-size:19px;">  
                  توصيل مجاني + عروض رائعة </h6>
</div>
<!-- top text -->
<div class="container-fluid">
	<div class="row w-100 " >
		<div class="col-md-12  col-sm-12 col-12 text-center text-white pt-2 pb-2">
		
		</div>
	</div>		
</div>

<!-- End of top text -->



	<div class="row w-100">
		<div class="col-2 order-2"></div>
			<div class="col-md-3 col-lg-3 col-2 col-sm-2 order-sm-2 order-lg-1 order-md-2 order-3" style="">
					<center>
					 	<img src="images/search.png" class="search" height="35px">
					 </center>
	    </div>
	<div class="col-md-6 col-md-6 col-sm-7 col-7 order-sm-1 order-lg-1 order-md-1 order-1" style="margin-top:-18px;">
			<center><img src="images/logo.png" class="logo" height="78px" width="30%"></center>
	</div>

	</div>



<!-- navbar -->
 <nav class="navbar mt-2">
        <div class="navbar-container container">
            <input type="checkbox" name="" id="">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="product.php">مساحة تخزين عصرية للمطبخ او الحمام </a></li>
                <li><a href="productlist.php">عصارة الفواكه الذكية (جودة ممتازة) </a></li>
                <li><a href="privacy.php">سياسة الخصوصية </a></li>
                <li><a href="terms-services.php">لشروط والاحكام  </a></li>
                <li><a href="refund.php"> سياسة الإسترجاع   </a></li>
                <li><a href="contact.php">تواصل معنا </a></li>
            </ul>
        </div>
    </nav>
 </div>
<!-- End Navbar -->

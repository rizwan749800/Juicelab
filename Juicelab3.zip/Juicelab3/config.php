<?php
include('stripe-php-master/init.php');

$publishKey = "pk_test_51MY8YnHy9MICtNdqBnH8rx3vfd4l5je7Go2fDmmbtxb1TZ5GL5NgwuY9YztGiwImmkPyrEGwMn44ulVxcFKWmNqO00v6PKnmk4";
$secretKey="sk_test_51MY8YnHy9MICtNdq7KBAZUmCgV4CuwwVwIRhUfzMXWI4KpuCTVf1H6LQtG1v36oBngtppS5rWw7bwSTDp719RoaN00nwcOAIu5";

\Stripe\Stripe::setApiKey($secretKey);


?>